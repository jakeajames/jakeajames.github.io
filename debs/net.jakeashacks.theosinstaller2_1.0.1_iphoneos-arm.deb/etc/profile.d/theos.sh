export THEOS=/var/theos
export PATH=$THEOS/bin:$PATH
